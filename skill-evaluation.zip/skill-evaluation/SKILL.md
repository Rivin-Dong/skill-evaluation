---
name: skill-evaluation
description: >
  Evaluate any AI skill's quality through step-by-step diagnosis — measuring trigger accuracy,
  per-step execution (completion/correctness/quality), efficiency, and safety — then produce a
  structured report with Bad Cases highlighted and actionable fixes. Supports iterative
  optimization with version control. Use this skill whenever someone wants to test a skill,
  evaluate prompt quality, benchmark a skill, diagnose why a skill underperforms, compare
  skill versions, check if a skill is production-ready, or get a quality assessment for any
  AI skill or prompt.
---

# Skill Eval

A diagnostic instrument for AI skills. Feed it any skill, get back a structured report that
tells you exactly what's working, what's broken (Bad Cases), and what to fix — then iterate
until the skill passes.

## Philosophy

Most skill testing today is vibes-based: run a couple of examples, eyeball the output, ship it.
That's fine for prototyping. It's not fine for anything you're putting in front of real users.

Skill Eval treats evaluation as diagnosis:

1. **Low-score system, not percentage** — Steps are scored on 2-point or 3-point scales, not
   100-point scales. Simple and honest: did it complete? Was it correct? Did it follow the rules?
2. **Three independent scores per step** — Completion (0/1), Correctness (0/1/2), Execution
   Quality (0/1/2). Never combined into a weighted total. Each tells you something different.
3. **Bad Cases first** — The report leads with failures, not averages. A 1.8/2 average means
   nothing if one case completely breaks.
4. **Iterative optimization** — Test, find Bad Cases, fix the skill, re-test. Track versions.
   Stop when Bad Cases reach zero.
5. **Expected results before execution** — Every test case defines what SHOULD happen, step by
   step. Scoring compares actual vs expected. No post-hoc rationalization.
6. **Baseline proves value** — Run the same cases without the skill to prove it actually helps.
   A skill that doesn't beat the bare model has no reason to exist.
7. **Scoring stability is verifiable** — In Deep Eval mode, the Judge scores 3 times. If scores
   diverge, the result is marked UNCERTAIN and requires human arbitration.
8. **Code checks before LLM checks** — Every `must_contain` item has a `check_type` (exact,
   regex, or semantic). Exact and regex are checked by code. Only semantic uses LLM judgment.

---

## When to Use This Skill

- You've written a skill and want to know if it's actually good before sharing it
- You've made changes and want to verify version N+1 fixed the Bad Cases from version N
- A skill "works sometimes" and you need to find out exactly which steps fail and why
- You need a quality gate before deploying a skill to production
- Someone asks "is this prompt/skill any good?" and you want a rigorous answer

## When NOT to Use This Skill

- You want to **create** a skill from scratch (use skill-creator for that)
- The "skill" is a single-line prompt with no structure (but see Phase 0 — we can still
  infer steps from unstructured prompts)

---

## The Evaluation Pipeline

```
  Input Skill
      |
      v
  [Phase 0] Structure Assessment ──> Testability level + eval strategy
      |
      v
  [Phase 1] Skill Dissection     ──> Step list + operation types + expected outputs
      |
      v
  [Phase 2] Test Case Design     ──> Cases with per-step expected results + check_types
      |
      v
  [Phase 3] Execute & Record     ──> Per-step actual behavior + Baseline comparison run
      |
      v
  [Phase 4] Score & Verify       ──> Three scores per step + stability verification
      |
      v
  [Phase 5] Report & Iterate     ──> Bad Cases + averages + Baseline gain + optimization
```

### Phase 0: Structure Assessment

Before doing anything else, evaluate the skill's testability:

1. Run the **structure checklist** (see `references/methodology.md` §1B):
   - Has explicit step numbers/titles?
   - Each step has input/output description?
   - Has method/tool specifications?
   - Has constraints?
   - Has expected deliverable description?

2. Determine **structure level**:
   - **High** (6/6 checks): Proceed directly to Phase 1
   - **Medium** (3-5/6): Supplement step expectations, then proceed
   - **Low** (0-2/6): Infer steps from the prompt text using verb-based decomposition

3. For low-structure skills, **infer steps**:
   - Identify verb instructions: search, analyze, extract, generate, output...
   - Order by logical dependency
   - Each verb = one inferred step
   - Mark all inferred steps with `"step_source": "inferred"`

### Phase 1: Skill Dissection

Read the target skill and build a structured profile:

1. Read the skill's SKILL.md (or .mdc, or plain text prompt)
2. Extract frontmatter: name, description, version
3. Identify the skill's **claimed steps** — the logical phases it asks the model to go through.
   Look for numbered lists, markdown headers like `### Step N`, or sequential instructions.
   If the skill doesn't have explicit steps, infer them from the instruction flow.
4. For each step, identify the **operation type**:
   - Data reading (files, databases, user input)
   - API calling (REST, GraphQL, third-party services)
   - Web scraping (page fetching, data extraction)
   - Page manipulation (clicking, form filling, navigation)
   - Data processing (calculation, transformation, aggregation)
   - Content generation (writing, code generation, report creation)
   - File output (saving, exporting)
   - Conditional logic (branching, error handling)
   - Tool invocation (search, external scripts)
5. Identify **output expectations** — what format, what artifacts, what deliverables.
6. Note any **safety-relevant instructions** — file system access, network calls, secrets.

Save this as the **Skill Profile**.

### Phase 2: Test Case Design

Based on the Skill Profile, design test cases. Each test case has:

- A **task prompt** — what a real user would say
- **Input files/context** (if applicable) — realistic test data
- **Per-step expected results** — for each step, what should happen and what the output should be
- **Skill requirements reference** — which Skill instructions apply to each step

**Test case structure:**

```json
{
  "test_case_id": "TC-001",
  "name": "descriptive name",
  "category": "normal | edge_case | adversarial | concurrent | multi_turn_deviate",
  "input": {
    "user_query": "the task prompt",
    "context_files": []
  },
  "expected_results": {
    "per_step": [
      {
        "step": "Step 1: step name",
        "operation_type": "api_call | web_scrape | page_action | ...",
        "expected_action": "what action should be taken",
        "expected_output": "what the output should look like",
        "must_contain": [
          {"value": "required element", "check_type": "exact"},
          {"value": "conceptual requirement", "check_type": "semantic"}
        ],
        "must_not_contain": [
          {"value": "forbidden element", "check_type": "exact"}
        ],
        "scoring_scale": {
          "correctness": 3,
          "quality": 3
        }
      }
    ]
  },
  "skill_requirements_ref": [
    "SKILL.md Step N: relevant requirement text"
  ]
}
```

**check_type for must_contain** (critical for scoring reliability):

| check_type | How it's verified | Use when |
|-----------|-------------------|----------|
| `"exact"` | Code: `value in output` | URLs, keywords, field names, numbers |
| `"regex"` | Code: `re.search(pattern, output)` | Formatted content, patterns with variants |
| `"semantic"` | LLM judges: "does output contain this concept?" | Abstract concepts, paraphrases |

**Rule: Use exact/regex whenever possible. Only use semantic for truly conceptual checks.**

**How many test cases?**

- **Quick eval** (default): 4 cases — normal flow, edge case, adversarial input, one more relevant
- **Deep eval**: 8-12 cases covering the full input space

**Critical rule:** Expected results must be written BEFORE execution. Never adjust expectations
after seeing results.

### Phase 3: Execute & Record

For each test case, execute the skill and record per-step behavior:

1. Run the task with the skill active
2. For each step in the skill, record:
   - What action was actually taken
   - What output was actually produced
   - Tool calls with parameters and responses
   - Timing data (tokens consumed, duration)
3. Identify step boundaries in the execution transcript
4. **Run Baseline** (at least once): Execute the same cases WITHOUT the skill to establish
   what the bare model can do. Store in `runs/run-{date}-baseline/`.

Save to `runs/{run-id}/results.json`.

### Phase 4: Score & Verify

For each step of each test case, produce THREE independent scores:

#### Automated Checks First (check_type: exact/regex)

Before LLM scoring, run code-based verification:
- All `must_contain` items with `check_type: "exact"` → string match
- All `must_contain` items with `check_type: "regex"` → regex match
- All `must_not_contain` items → inverse check

These results are deterministic and feed into the correctness score.

#### LLM Scoring (check_type: semantic + quality judgments)

#### Completion (2-point scale: 0/1)

```
0 = Not completed: The step was not executed, or the core operation did not happen
1 = Completed: The core operation was executed (regardless of whether the result is correct)
```

Only checks "did it do the thing?" — not whether the thing was done well.

#### Correctness (3-point scale: 0/1/2, or 2-point for binary outcomes)

Compare **expected result vs actual result**:

```
0 = Wrong: Actual result seriously doesn't match expected, core requirements unmet
1 = Partially correct: Partially matches expected, some omissions or deviations but right direction
2 = Fully correct: Actual result fully matches expected, or exceeds expectations
```

Correctness standards vary by operation type (see `references/methodology.md` section 3.2).

#### Execution Quality (3-point scale: 0/1/2)

Compare **Skill's instructions vs actual execution process**:

```
0 = Non-compliant: Completely ignored the Skill's specified method/constraints
1 = Partially compliant: Mostly followed Skill requirements but minor violations
2 = Fully compliant: Strictly followed the Skill's methods and constraints
```

#### Low-Score Reason (mandatory when any score < max)

Every step that doesn't get full marks MUST include a `low_score_reason` explaining:
1. What was expected vs what actually happened
2. Which Skill requirement was violated (with reference)
3. Why this score and not higher/lower

**The three scores are NEVER combined into a weighted total.** They are displayed independently.

#### Scoring Stability Verification (Deep Eval mode)

In Deep Eval mode, the Judge scores each step **3 times**:

- If all 3 scores match → **Stable** (use the score)
- If 2 of 3 match → **Mostly stable** (use the majority, note `"stability": "majority"`)
- If all 3 differ → **Unstable** (mark as `"UNCERTAIN"`, exclude from averages, flag for
  human arbitration)

This ensures that reported scores are reproducible, not artifacts of LLM randomness.

**Stability tips:**
- `check_type: "exact"` items are always stable (code-verified)
- Lower temperature (0) reduces instability
- More specific `expected` descriptions reduce judgment variance

### Phase 5: Report & Iterate

Generate the evaluation report with this structure (in order of priority):

1. **Bad Case Section** (FIRST — most important)
2. **Overview Panel** (averages across all dimensions + Baseline gain summary)
3. **Scoring Stability Summary** (how many UNCERTAIN items, if Deep Eval)
4. **Step Scores Table** (per-step averages for all three scores)
5. **Baseline Comparison** (skill vs bare model, per-step)
6. **Efficiency Details** (per-step token/time averages)
7. **Safety Details** (unsafe rate + findings)
8. **Trigger Details** (precision/recall if available)
9. **Full Case Details** (every case, every step, all scores + reasons)

Then proceed to the **iteration loop**:
- Identify Bad Cases and their root causes
- Generate an optimization plan targeting specific Bad Cases
- Create a new skill version
- Re-run the same test cases
- Compare versions
- Repeat until Bad Cases = 0

---

## Dimensions

### Trigger — Percentage

```
Precision = true triggers / total triggers
Recall = true triggers / should-have-triggered
```

Displayed as percentages. If trigger eval can't run, mark as SKIPPED.

### Execution + Quality — Low-Score System (Combined)

Every step gets three independent scores. Display as averages:

```
Overall:  Completion avg: 0.85/1  |  Correctness avg: 1.42/2  |  Quality avg: 1.65/2
```

Plus per-step breakdown table.

### Efficiency — Raw Values

No scores. Display actual numbers:
- Average total tokens per case
- Average total time per case
- Per-step average tokens and time

### Safety — Binary + Unsafe Rate

Each safety check is pass/fail. Display:
```
Unsafe rate = unsafe findings / total checks
```

CRITICAL findings get highlighted with a warning banner.

---

## Bad Case Definition

A test case (or a specific step within a case) is a **Bad Case** if ANY of:

| Condition | Meaning |
|-----------|---------|
| Completion = 0 | Step was not executed at all |
| Correctness = 0 | Result was completely wrong |
| Execution Quality = 0 | Completely violated Skill requirements |
| Safety finding present | Unsafe behavior detected |

Bad Cases are displayed first in the report, with full details:
- Which step failed
- Three scores
- Expected vs actual
- Low-score reason with Skill requirement reference

---

## Version Control & Iteration

All evaluation artifacts are versioned. See `references/methodology.md` section 12 for the
full storage spec. Key rules:

### Directory Structure

```
{workspace}/
├── skill/v1/SKILL.md          # Frozen skill snapshot
├── skill/v2/SKILL.md          # After first optimization
├── test-cases/v1/cases.json   # Test case set
├── runs/run-{date}-v1/        # Execution results
├── reports/v1/report.json     # Evaluation report
├── optimizations/OPT-001.json # Optimization plan
└── changelog.json             # Version history
```

### Version Rules

1. **Skill snapshots are immutable** — once saved, never modified. Changes create v(N+1).
2. **Test cases only grow** — can add new cases, never delete or modify existing ones.
3. **Every run is preserved** — execution results are never overwritten.
4. **Optimizations reference Bad Cases** — every change must cite which Bad Case it fixes.
5. **Regressions are flagged** — if a new version makes a previously-passing case fail, it's
   immediately highlighted in the comparison report.

### Iteration Stop Conditions

Stop iterating when ALL of:
- Bad Case count = 0
- Correctness average >= 1.8/2
- No regressions from previous version
- Unsafe rate = 0%

If 3 iterations don't reach this, the skill may need fundamental redesign, not tweaks.

---

## Presenting the Report

### Bad Cases First

```
╔═══════════════════════════════════════════════════════════════════╗
║  🔴 BAD CASES (3 cases, 30% of total)                            ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  TC-003 "Edge case: empty input"                                  ║
║  Failed step: Step 3 [page_action] Submit form                    ║
║  Completion: 0 | Correctness: 0 | Quality: 0                     ║
║  Expected: Show error "Please fill required fields"               ║
║  Actual: Submitted empty form, got 500 error                      ║
║  Reason: Core validation not performed (ref: SKILL.md Step 3)     ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

### Overview Panel

```
╔═══════════════════════════════════════════════════════════════════╗
║  SKILL EVALUATION REPORT                                         ║
║  Skill: {name}  Version: v1  Date: {date}                        ║
║  Cases: 10     Bad Cases: 3 (30%) 🔴                              ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  Trigger:      Precision: 83%    Recall: 100%                    ║
║  Completion:   avg 0.85/1                                        ║
║  Correctness:  avg 1.42/2                                        ║
║  Exec Quality: avg 1.65/2                                        ║
║  Efficiency:   avg 18,420 tokens/case  avg 45.2s/case            ║
║  Safety:       unsafe rate 10% (2/20)                            ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

### Step Scores Table

```
┌───────────────────────┬───────────┬──────────┬──────────┬───────────────┐
│ Step                   │ Completion│Correctness│ Quality  │ Low-score note│
│                       │ (avg/1)   │ (avg/2)  │ (avg/2)  │               │
├───────────────────────┼───────────┼──────────┼──────────┼───────────────┤
│ Step 1: Search API    │  1.0      │  1.8     │  2.0     │ —             │
│ Step 2: Parse data    │  0.9      │  1.5     │  1.7     │ —             │
│ Step 3: Web scrape    │  0.8      │  1.1     │  1.2     │ Incomplete    │
│ Step 5: Generate report│  0.6 ⚠️  │  0.9 ⚠️  │  1.0 ⚠️  │ Format issues │
└───────────────────────┴───────────┴──────────┴──────────┴───────────────┘
```

---

## Reference Files

- `references/methodology.md` — Full methodology: scoring rules, iteration process, version control
- `references/schemas.md` — JSON schemas for all data structures
- `references/rubrics.md` — Reusable rubric templates by skill category
- `references/scoring.md` — Legacy scoring formulas (kept for reference)
- `agents/judge.md` — The scoring agent protocol
- `agents/advisor.md` — The diagnostic advisor protocol
- `scripts/score_engine.py` — Score computation engine
- `scripts/safety_scanner.py` — Static safety analysis
- `scripts/generate_scorecard.py` — Report generation
- `scripts/run_trigger_eval.py` — Trigger evaluation

---

## The Non-Negotiables

1. **Expected results before execution.** Every test case defines what should happen before
   seeing what actually happens. No post-hoc grading.

2. **Low scores must have explanations.** Any score below maximum requires a `low_score_reason`
   citing expected vs actual and which Skill requirement was violated.

3. **Bad Cases are shown first.** The report leads with failures. Good averages don't hide
   broken cases.

4. **Three scores stay independent.** Completion, correctness, and execution quality are NEVER
   combined into a weighted total. Each means something different.

5. **Versions are immutable.** Once a skill version, test run, or report is saved, it's frozen.
   Changes produce new versions.

6. **Every fix traces to a Bad Case.** No "vibes-based" optimization. Every change references
   the specific Bad Case it addresses.

7. **Regressions are zero-tolerance.** A new version must not break what the old version passed.

8. **Structure check before testing.** Phase 0 assesses testability. Low-structure skills get
   steps inferred; untestable skills get sent back to the author.

9. **Baseline proves the skill's value.** At least one baseline run required. If the skill
   performs worse than bare model on any step, that's a critical finding.

10. **Scoring stability is verified.** Deep Eval scores 3x per step. UNCERTAIN results require
    human arbitration before the report is finalized.

11. **Code checks before LLM checks.** Every must_contain with check_type "exact" or "regex"
    is verified by code. Only "semantic" items use LLM judgment.

12. **Multi-turn skills must test deviation.** If a skill involves multi-turn conversation,
    test cases must include `multi_turn_deviate` scenarios (user changes mind, cancels, etc).
