"""skill-evaluation scripts package."""
