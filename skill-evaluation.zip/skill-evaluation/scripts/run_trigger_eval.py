#!/usr/bin/env python3
"""Run trigger evaluation for a skill's description.

Tests whether a skill's description causes the model to trigger (read/activate the skill)
for a set of probe queries. Outputs precision, recall, and individual results as JSON.

This is a standalone trigger evaluator — it doesn't depend on the rest of the evaluation
pipeline and can be run independently.
"""

import argparse
import json
import os
import select
import subprocess
import sys
import time
import uuid
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


def find_project_root() -> Path:
    """Walk up from cwd looking for .claude/ to find the project root."""
    current = Path.cwd()
    for parent in [current, *current.parents]:
        if (parent / ".claude").is_dir():
            return parent
    return current


def probe_single_query(
    query: str,
    skill_name: str,
    skill_description: str,
    timeout: int,
    project_root: str,
    model: str | None = None,
) -> bool:
    """Run one query and return whether it triggered the skill.

    Creates a temporary command file so the skill appears in available_skills,
    then runs `claude -p` and watches stream events for tool_use targeting our skill.
    """
    uid = uuid.uuid4().hex[:8]
    probe_name = f"{skill_name}-probe-{uid}"
    commands_dir = Path(project_root) / ".claude" / "commands"
    command_file = commands_dir / f"{probe_name}.md"

    try:
        commands_dir.mkdir(parents=True, exist_ok=True)
        indented_desc = "\n  ".join(skill_description.split("\n"))
        command_file.write_text(
            f"---\ndescription: |\n  {indented_desc}\n---\n\n"
            f"# {skill_name}\n\nThis skill handles: {skill_description}\n"
        )

        cmd = [
            "claude", "-p", query,
            "--output-format", "stream-json",
            "--verbose",
            "--include-partial-messages",
        ]
        if model:
            cmd.extend(["--model", model])

        env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            cwd=project_root,
            env=env,
        )

        triggered = False
        start = time.time()
        buffer = ""
        pending_tool = None
        accumulated = ""

        try:
            while time.time() - start < timeout:
                if process.poll() is not None:
                    remaining = process.stdout.read()
                    if remaining:
                        buffer += remaining.decode("utf-8", errors="replace")
                    break

                ready, _, _ = select.select([process.stdout], [], [], 1.0)
                if not ready:
                    continue

                chunk = os.read(process.stdout.fileno(), 8192)
                if not chunk:
                    break
                buffer += chunk.decode("utf-8", errors="replace")

                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    line = line.strip()
                    if not line:
                        continue

                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    if event.get("type") == "stream_event":
                        se = event.get("event", {})
                        se_type = se.get("type", "")

                        if se_type == "content_block_start":
                            cb = se.get("content_block", {})
                            if cb.get("type") == "tool_use":
                                tool = cb.get("name", "")
                                if tool in ("Skill", "Read"):
                                    pending_tool = tool
                                    accumulated = ""
                                else:
                                    return False

                        elif se_type == "content_block_delta" and pending_tool:
                            delta = se.get("delta", {})
                            if delta.get("type") == "input_json_delta":
                                accumulated += delta.get("partial_json", "")
                                if probe_name in accumulated:
                                    return True

                        elif se_type in ("content_block_stop", "message_stop"):
                            if pending_tool:
                                return probe_name in accumulated
                            if se_type == "message_stop":
                                return False

                    elif event.get("type") == "assistant":
                        message = event.get("message", {})
                        for item in message.get("content", []):
                            if item.get("type") != "tool_use":
                                continue
                            name = item.get("name", "")
                            inp = item.get("input", {})
                            if name == "Skill" and probe_name in inp.get("skill", ""):
                                triggered = True
                            elif name == "Read" and probe_name in inp.get("file_path", ""):
                                triggered = True
                            return triggered

                    elif event.get("type") == "result":
                        return triggered

        finally:
            if process.poll() is None:
                process.kill()
                process.wait()

        return triggered

    finally:
        if command_file.exists():
            command_file.unlink()


def run_trigger_eval(
    queries: list[dict],
    skill_name: str,
    description: str,
    workers: int = 6,
    timeout: int = 30,
    model: str | None = None,
) -> dict:
    """Run all trigger probes and compute precision/recall."""
    project_root = find_project_root()
    results = []

    with ProcessPoolExecutor(max_workers=workers) as executor:
        future_map = {}
        for item in queries:
            future = executor.submit(
                probe_single_query,
                item["query"], skill_name, description,
                timeout, str(project_root), model,
            )
            future_map[future] = item

        for future in as_completed(future_map):
            item = future_map[future]
            try:
                did_trigger = future.result()
            except Exception as e:
                print(f"Warning: probe failed: {e}", file=sys.stderr)
                did_trigger = False

            should = item["should_trigger"]
            passed = (did_trigger == should)
            results.append({
                "query": item["query"],
                "should_trigger": should,
                "did_trigger": did_trigger,
                "pass": passed,
            })

    # Compute precision and recall
    tp = sum(1 for r in results if r["should_trigger"] and r["did_trigger"])
    fp = sum(1 for r in results if not r["should_trigger"] and r["did_trigger"])
    fn = sum(1 for r in results if r["should_trigger"] and not r["did_trigger"])
    tn = sum(1 for r in results if not r["should_trigger"] and not r["did_trigger"])

    precision = tp / (tp + fp) if (tp + fp) > 0 else 1.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 1.0
    accuracy = (tp + tn) / len(results) if results else 0.0
    trigger_score = round((precision * 0.5 + recall * 0.5) * 100)

    return {
        "skill_name": skill_name,
        "description": description,
        "results": results,
        "metrics": {
            "precision": round(precision, 3),
            "recall": round(recall, 3),
            "accuracy": round(accuracy, 3),
            "true_positives": tp,
            "false_positives": fp,
            "false_negatives": fn,
            "true_negatives": tn,
        },
        "trigger_score": trigger_score,
    }


def parse_skill_frontmatter(skill_path: Path) -> tuple[str, str]:
    """Extract name and description from SKILL.md frontmatter."""
    content = (skill_path / "SKILL.md").read_text(encoding="utf-8")
    name, description = "unknown", ""

    if content.startswith("---"):
        end = content.index("---", 3)
        front = content[3:end]
        for line in front.split("\n"):
            if line.startswith("name:"):
                name = line.split(":", 1)[1].strip()
            elif line.startswith("description:"):
                desc_part = line.split(":", 1)[1].strip()
                if desc_part.startswith(">"):
                    # Multi-line scalar — collect subsequent indented lines
                    desc_lines = []
                    idx = front.index(line) + len(line) + 1
                    for fline in front[idx:].split("\n"):
                        if fline.startswith("  "):
                            desc_lines.append(fline.strip())
                        elif fline.strip() == "":
                            continue
                        else:
                            break
                    description = " ".join(desc_lines)
                else:
                    description = desc_part

    return name, description


def main():
    parser = argparse.ArgumentParser(description="Run trigger evaluation for a skill")
    parser.add_argument("--skill-path", required=True, help="Path to skill directory")
    parser.add_argument("--queries", required=True, help="Path to trigger queries JSON")
    parser.add_argument("--workers", type=int, default=6, help="Parallel workers")
    parser.add_argument("--timeout", type=int, default=30, help="Timeout per probe (seconds)")
    parser.add_argument("--model", default=None, help="Model for claude -p")
    parser.add_argument("--output", default=None, help="Save results to file")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    skill_path = Path(args.skill_path)
    queries = json.loads(Path(args.queries).read_text())
    name, description = parse_skill_frontmatter(skill_path)

    if args.verbose:
        print(f"Evaluating trigger for: {name}", file=sys.stderr)
        print(f"Description: {description[:80]}...", file=sys.stderr)
        print(f"Queries: {len(queries)}", file=sys.stderr)

    results = run_trigger_eval(queries, name, description, args.workers, args.timeout, args.model)

    if args.verbose:
        m = results["metrics"]
        print(f"\nPrecision: {m['precision']:.0%}  Recall: {m['recall']:.0%}  Score: {results['trigger_score']}", file=sys.stderr)
        for r in results["results"]:
            icon = "✓" if r["pass"] else "✗"
            print(f"  {icon} trigger={r['did_trigger']}  expected={r['should_trigger']}  {r['query'][:60]}", file=sys.stderr)

    output = json.dumps(results, indent=2)
    if args.output:
        Path(args.output).write_text(output)
    else:
        print(output)


if __name__ == "__main__":
    main()
